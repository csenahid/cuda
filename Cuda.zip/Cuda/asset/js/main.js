$(document).ready(function(){
    var mixer = mixitup('.container');
});